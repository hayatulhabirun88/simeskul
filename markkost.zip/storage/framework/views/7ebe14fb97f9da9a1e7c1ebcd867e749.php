<?php $__env->startSection('title'); ?>
    Profil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Halaman /</span> Profil</h4>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Profile Lengkap</h5>
                    <!-- Account -->
                    <div class="card-body">
                        <div class="d-flex align-items-start align-items-sm-center gap-4">
                            <img src="<?php echo e(asset('/')); ?>backend/assets/img/avatars/1.png" alt="user-avatar"
                                class="d-block rounded" height="100" width="100" id="uploadedAvatar">
                        </div>
                    </div>
                    <hr class="my-0">
                    <div class="card-body">
                        <form method="POST" onsubmit="return false">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="name" class="form-label">Nama</label>
                                    <input class="form-control" type="text"
                                        value="<?php echo e(old('name', auth()->user()->name)); ?>" id="name" name="name"
                                        value="John" autofocus="">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input class="form-control" type="text" id="email" name="email"
                                        value="<?php echo e(old('email', auth()->user()->email)); ?>"
                                        placeholder="john.doe@example.com">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="no_tlp" class="form-label">No Telepon</label>
                                    <input type="text" class="form-control" id="no_tlp" name="no_tlp"
                                        value="<?php echo e(old('no_tlp', auth()->user()->no_tlp)); ?>">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="level" class="form-label">Level</label>
                                    <select class="form-select form-select" name="level" id="level">
                                        <option selected>Pilih Level</option>
                                        <option value="pemilik_kost"
                                            <?php echo e(old('level', auth()->user()->level) == 'pemilik_kost' ? 'selected' : ''); ?>>
                                            Pemilik Kost</option>
                                        <option value="penyewa"
                                            <?php echo e(old('level', auth()->user()->level) == 'penyewa' ? 'selected' : ''); ?>>Penyewa
                                        <option value="admin"
                                            <?php echo e(old('level', auth()->user()->level) == 'admin' ? 'selected' : ''); ?>>Admin
                                        </option>
                                    </select>
                                </div>

                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Simpan Profil</button>
                            </div>
                        </form>
                    </div>
                    <!-- /Account -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/profil/profil.blade.php ENDPATH**/ ?>