<?php $__env->startSection('title'); ?>
    Data Kost
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-9 d-flex align-items-center">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Halaman /</span> Data Kost</h4>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="row">
                <div class="col-md-9">
                    <h5 class="card-header">Data Kost</h5>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kode Booking</th>
                            <th>Nama Pemesan</th>
                            <th>Nama Kost</th>
                            <th>Status Booking</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php if(count($booking) > 0): ?>
                            <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>BK-<?php echo e($bk->id); ?></td>

                                    <td><?php echo e($bk->user->name); ?></td>
                                    <td><?php echo e($bk->datakost->nama_kost); ?></td>
                                    <td>
                                        <?php if($bk->status_booking == 'Dipesan'): ?>
                                            <span class="badge bg-secondary"><?php echo e($bk->status_booking); ?></span>
                                        <?php elseif($bk->status_booking == 'Dibayar'): ?>
                                            <span class="badge bg-success"><?php echo e($bk->status_booking); ?></span>
                                        <?php elseif($bk->status_booking == 'Konfirmasi'): ?>
                                            <span class="badge bg-primary"><?php echo e($bk->status_booking); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e($bk->status_booking); ?></span>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal"
                                            data-bs-target="#konfirmasi<?php echo e($bk->id); ?>">
                                            Konfirmasi
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#batal<?php echo e($bk->id); ?>">
                                            Batal
                                        </button>
                                    </td>
                                </tr>
                                

                                <div class="modal fade" id="konfirmasi<?php echo e($bk->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-sm" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">Konfirmasi
                                                </h5>
                                            </div>
                                            <div class="modal-body">
                                                <br>
                                                <div class="text-center">Apakah anda yakin <br> akan mengkonfirmasi booking
                                                    <br> an.
                                                    <?php echo e($bk->user->name); ?> ?
                                                </div>
                                                <form action="<?php echo e(route('booking.konfirmasi', $bk->id)); ?>" method="post"
                                                    style="display: inline-block">
                                                    <?php echo csrf_field(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-primary">Konfirmasi</button>
                                                </form>
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="batal<?php echo e($bk->id); ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-sm" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">Hapus
                                                </h5>
                                            </div>
                                            <div class="modal-body">
                                                <br>
                                                <div class="text-center">Apakah anda yakin <br> akan membatalkan booking
                                                    <br> an.
                                                    <?php echo e($bk->user->name); ?> ?
                                                </div>
                                                <form action="<?php echo e(route('booking.batal', $bk->id)); ?>" method="post"
                                                    style="display: inline-block">
                                                    <?php echo csrf_field(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-danger">Batal</button>
                                                </form>
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="text-center">
                                <td colspan="5">Tidak Ditemukan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div><br><br>
            <div class="pagination justify-content-center">
                <ul class="pagination">
                    <li class="page-item <?php echo e($booking->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($booking->previousPageUrl()); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>

                    <?php $__currentLoopData = $booking->getUrlRange(1, $booking->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($page == $booking->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="page-item <?php echo e($booking->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" href="<?php echo e($booking->nextPageUrl()); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/booking/booking.blade.php ENDPATH**/ ?>