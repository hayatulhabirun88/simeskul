<?php $__env->startSection('title'); ?>
    Pengguna
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-9">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Halaman /</span> Pengguna</h4>
            </div>
            <div class="col-md-3 d-flex justify-content-end align-items-center">
                <a href="/pengguna/create" class="btn btn-primary">Tambah</a>
            </div>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="row">
                <div class="col-md-9">
                    <h5 class="card-header">Pengguna</h5>
                </div>

            </div>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>No Telp</th>
                            <th>Dokumentasi KTP</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php if(count($user) > 0): ?>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + $user->firstItem()); ?></td>
                                    <td><?php echo e($usr->name); ?></td>
                                    <td><?php echo e($usr->no_tlp); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#dokktpModal<?php echo e($usr->id); ?>">
                                            Lihat KTP
                                        </button>
                                    </td>
                                    <td>
                                        <?php if($usr->level == 'pemilik_kost'): ?>
                                            <span class="badge bg-label-primary me-1">Pemilik</span>
                                        <?php elseif($usr->level == 'penyewa'): ?>
                                            <span class="badge bg-label-info me-1">Pengguna</span>
                                        <?php else: ?>
                                            <span class="badge bg-label-success">Admin</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="/pengguna/<?php echo e($usr->id); ?>/edit" class="btn btn-sm btn-warning"><i
                                                class='bx bxs-edit'></i></a>

                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#deleteUser<?php echo e($usr->id); ?>">
                                            <i class='bx bx-trash'></i>
                                        </button>


                                    </td>
                                </tr>
                                <div class="modal fade" id="dokktpModal<?php echo e($usr->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">KTP <?php echo e($usr->name); ?>

                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?php if($usr->dok_ktp): ?>
                                                    <img width="100%" src="<?php echo e(asset('/')); ?>images/<?php echo e($usr->dok_ktp); ?>"
                                                        alt="">
                                                <?php else: ?>
                                                    <h4>KTP Belum di upload</h4>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                

                                <div class="modal fade" id="deleteUser<?php echo e($usr->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-sm" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">Hapus
                                                </h5>
                                            </div>
                                            <div class="modal-body">
                                                <br>
                                                <div class="text-center">Apakah anda yakin <br> akan menghapus data <br> an.
                                                    <?php echo e($usr->name); ?> ?</div>
                                                <form action="<?php echo e(route('destroy.pengguna', $usr->id)); ?>" method="post"
                                                    style="display: inline-block">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-danger">Hapus</button>
                                                </form>
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="text-center">
                                <td colspan="6">Tidak Ditemukan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div><br><br>
            <div class="pagination justify-content-center">
                <ul class="pagination">
                    <li class="page-item <?php echo e($user->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($user->previousPageUrl()); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <?php $__currentLoopData = $user->getUrlRange(1, $user->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($page == $user->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="page-item <?php echo e($user->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" href="<?php echo e($user->nextPageUrl()); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/pengguna/pengguna.blade.php ENDPATH**/ ?>